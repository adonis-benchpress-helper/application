function increaseWeight(context) {
    addAction({
        type:"increase_weight"
    }, context)
}

function decreaseWeight(context) {
    addAction({
        type:"decrease_weight"
    }, context)
}

function increaseReps(context) {
    addAction({
        type:"increase_reps"
    }, context)
}

function decreaseReps(context) {
    addAction({
        type:"decrease_reps"
    }, context)
}

function calcMax(context) {
    addAction({
        type:"calc_max"
    }, context)
}